## ----setup, include=FALSE, cache=FALSE--------------------------------------------------
try(knitr::opts_chunk$set(dev="pdf", tidy=FALSE, comment="#"), silent=TRUE)
options(warn=1)
options(width=90)
ptime <- proc.time()

## ----eval=FALSE-------------------------------------------------------------------------
#  install.packages(c("NADA", "rgdal"))
#  install.packages("Trends", repos = "http://jfisher-usgs.github.com/R/")

## ---------------------------------------------------------------------------------------
library(Trends)

## ---------------------------------------------------------------------------------------
print(merge.pdfs <- as.logical(nchar(Sys.which("pdftk"))))

## ---------------------------------------------------------------------------------------
list.files(path.in <- system.file("extdata", "SIR2014", package = "Trends"))

## ---------------------------------------------------------------------------------------
path.out <- file.path(getwd(), paste0("Trends_", format(Sys.time(), "%Y%m%d%H%M%S")))
dir.create(path = path.out, showWarnings = FALSE)

## ---------------------------------------------------------------------------------------
gr.type <- "pdf"

## ---------------------------------------------------------------------------------------
d <- ReadObservations(file.path(path.in, "Data.tsv"))

## ---------------------------------------------------------------------------------------
par.config <- ReadParConfig(file.path(path.in, "Config_Par.tsv"))

## ---------------------------------------------------------------------------------------
site.locs <- ReadSiteLocations(path.in, layer = "Site_Locations", verbose = FALSE)

## ---------------------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Plots.tsv"))
PlotObservations(d, par.config = par.config, plot.config = plot.config,
                 sdate = "01/01/1960", edate = "01/01/2013", gr.type = gr.type,
                 path.out = file.path(path.out, "Data_1960-2012"),
                 merge.pdfs = merge.pdfs)

## ---------------------------------------------------------------------------------------
PlotObservations(d, par.config = par.config, plot.config = plot.config,
                 sdate = "01/01/1989", edate = "01/01/2013", gr.type = gr.type,
                 path.out = file.path(path.out, "Data_1989-2012"),
                 merge.pdfs = merge.pdfs)

## ---------------------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Plots_Field.tsv"))
PlotObservations(d, par.config = par.config, plot.config = plot.config,
                 sdate = "01/01/1960", edate = "01/01/2013", gr.type = gr.type,
                 path.out = file.path(path.out, "Data_1960-2012_Field"),
                 merge.pdfs = merge.pdfs)

## ---------------------------------------------------------------------------------------
PlotObservations(d, par.config = par.config, plot.config = plot.config,
                 sdate = "01/01/1989", edate = "01/01/2013", gr.type = gr.type,
                 path.out = file.path(path.out, "Data_1989-2012_Field"),
                 merge.pdfs = merge.pdfs)

## ---------------------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Cen.tsv"))
out <- RunTrendAnalysis(d, par.config = par.config, plot.config = plot.config,
                        sdate = "01/01/1989", edate = "01/01/2013", is.censored = TRUE,
                        path.out = file.path(path.out, "Stats_1989-2012_Cen"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)

## ---------------------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Uncen.tsv"))
out <- RunTrendAnalysis(d, par.config=par.config, plot.config=plot.config,
                        sdate = "01/01/1960", edate = "01/01/2013", is.censored = FALSE,
                        path.out = file.path(path.out, "Stats_1960-2012_Uncen"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)

## ---------------------------------------------------------------------------------------
out <- RunTrendAnalysis(d, par.config = par.config, plot.config = plot.config,
                        sdate = "01/01/1989", edate = "01/01/2013", is.censored = FALSE,
                        path.out = file.path(path.out, "Stats_1989-2012_Uncen"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)

## ---------------------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Uncen_Field.tsv"))
out <- RunTrendAnalysis(d, par.config = par.config, plot.config = plot.config,
                        sdate = "01/01/1960", edate = "01/01/2013", is.censored = FALSE,
                        path.out = file.path(path.out, "Stats_1960-2012_Uncen_Field"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)

## ---------------------------------------------------------------------------------------
out <- RunTrendAnalysis(d, par.config = par.config, plot.config = plot.config,
                        sdate = "01/01/1989", edate = "01/01/2013", is.censored = FALSE,
                        path.out = file.path(path.out, "Stats_1989-2012_Uncen_Field"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)

## ---------------------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Cen_VOC.tsv"))
out <- RunTrendAnalysis(d, par.config = par.config, plot.config = plot.config,
                        sdate = "01/01/1987", edate = "01/01/2013", is.censored = TRUE,
                        path.out = file.path(path.out, "Stats_1987-2012_Cen_VOC"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)

## ---------------------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Uncen_VOC.tsv"))
out <- RunTrendAnalysis(d, par.config = par.config, plot.config = plot.config,
                        sdate = "01/01/1987", edate = "01/01/2013", is.censored = FALSE,
                        path.out = file.path(path.out, "Stats_1987-2012_Uncen_VOC"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)

## ----eval=FALSE-------------------------------------------------------------------------
#  source(system.file("doc", "Trends-process.R", package = "Trends"), echo = TRUE)
#  list.files(path.out, full.names = TRUE, recursive = TRUE) # path names of output files

## ----echo=FALSE, results="asis"---------------------------------------------------------
print(toLatex(sessionInfo(), locale=FALSE))

